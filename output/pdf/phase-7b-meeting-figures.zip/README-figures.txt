Phase 7b supervisor meeting figures - 22 September 2026

All five original G1 comparison plots are in G1/.
New geometry, removal-region, liquid-fraction and residual plots are in Meeting/.
S20, S40, S60 and S80 fields are saved N5000 states.
S100 fields are the preserved N4000 recovery state; it failed at attempted N4183.
All contour panels use native facet values, without interpolation or smoothing.
The liquid-fraction scale is 0 to 1. Geometric collector shading is not liquid fraction.
The white central area in the section plots is outside the sampled fluid domain.
All seven residual equations are retained. S100 residual panels together cover N1-4182.
No additional solve or checkpoint overwrite was performed for this report.

Scientific report: Project/experiments/phase-07b-full-geometry-liquid-removal/results.md
Exact runs and figure hashes are recorded in report-provenance.json.
